#undef main //eliminates duplicate main within SDL libraries
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "InstructorGameLogic.h"
//#include "MyGraphFunctions.h" include your graph library here

/*These two functions need to be modified */
int executeTurn(int turn, SDL_Renderer *ren, SDL_MouseButtonEvent e, Board *B);
int determineWinner();
/* You'll want to add a method for computerPlayerShort */

void DFS_Recursive(Board *B, int vertex, int *visited_array, SDL_Renderer *ren ) {
	char num_string[100];
    visited_array[vertex]=1;
    printf("Visiting vertex %d\n",vertex);
    sprintf(num_string,"%d",vertex);
    stringColor(ren, B->Vertices[vertex].x+5, B->Vertices[vertex].y+5, num_string, red);
    for (int i=0; i<B->num; i++) {
		// got an edge to a place I haven't been before
        if (B->edges[vertex][i]!=noArc && visited_array[i]==0)  {
			DFS_Recursive(B,i,visited_array,ren);
			}
	}
}

void DFS(Board *B, SDL_Renderer *ren ) {
	// I am going to make an array to keep track of who has been visited
    int *visited=malloc(B->num*sizeof(int));
	// nobody visited yet
	for (int i=0; i<B->num; i++) {
		visited[i]=0; 
	}
	DFS_Recursive(B,0,visited, ren);
}

/* The main method may need to be modified to add the selection of Player vs Player or Computer vs Player -- see below */

int main(int argc, char **argv) {
                SDL_Window *win = NULL;
                SDL_Renderer *ren = NULL;
                SDL_Event e;
                Board B;
                B.num = numNodes;

                int quit = GAME_UNDERWAY; 
                int turn = CUT_TURN; 

                // TODO!!!
                // Add a simple menu here that shows up in the black console window to choose PvP or Computer vs. Player


                // Probably don't need to modify anything else below

                initializeGraphicsWindow(&win, &ren);
                SDL_SetRenderDrawColor(ren, 255, 255, 255, 255); // creates a white background for the board
                SDL_RenderClear(ren); //clears the game board to ensure it is plain white
                SDL_RenderPresent(ren); //renders the gameboard to the screen
                
                if (turn){ stringColor(ren, 5, 5, "Short's Turn:", white); } //displays initial turn
                else{ stringColor(ren, 5, 5, "Cut's Turn:", black); }
               
                createAndDrawBoard(ren,&B);//generates random planar graph and draws it
                
                // now we have a Board!!
                DFS(&B,ren);

	//This is the main loop. 
	//It calls executeTurn once per mouse click until the user quits or someone wins
	while (quit==GAME_UNDERWAY){ 
		while (SDL_PollEvent(&e) != 0) //Loops through event queue
		{
			//User requests quit
			if (e.type == SDL_QUIT) //allows user to x out of program
			{
				quit = USER_QUIT;
			}
			if (e.type == SDL_MOUSEBUTTONDOWN) //handles mouse button events
			{
				turn = executeTurn(turn, ren, e.button, &B);
				quit = determineWinner();  //returns 0,2,or 3 as defined above inline with the declaration of quit
			}
		}
		SDL_RenderPresent(ren); //presents changes to the screen that result from the execution of one turn
	}

	// Display who won
	displayWinBanner(ren, quit);

	while ((quit == CUT_WINS) || (quit == SHORT_WINS))  //if there was a winner hold the screen until the game window is closed.
	{
		SDL_RenderPresent(ren); //present changes to the screen

		// wait until the user closes the window
		while (SDL_PollEvent(&e) != 0)
		{
			//User requests quit
			if (e.type == SDL_QUIT)
			{
				quit = USER_QUIT;
			}
		}
	}

	freeGraphicsWindow(&win, &ren);//Terminate SDL and end program
	deleteBoard(&B); //deallocates dynamic memory
	return 0;
}


/*****************************************************************************************************************************/
/********MODIFY THE FOLLOWING TWO FUNCTIONS TO FINISH THE GAME                                                         *******/
/*****************************************************************************************************************************/
/*
//these functions should use your graph library to model the logical game. 
*/

// This method checks to see if someone has won
// Return CUT_WINS, SHORT_WINS, or GAME_UNDERWAY (if noone has won yet)
int determineWinner()
{

	//if a path of locked arcs exist from A to B then switch wins. 
	//If there exists no path of remaining arcs from A to B then cut wins
	return GAME_UNDERWAY;
}

/*
Simple decision logic to handle each SDL event depending on who's turn it is
Returns CUT_TURN or SHORT_TURN depending on who will go next
*/
int executeTurn(int turn, SDL_Renderer *ren, SDL_MouseButtonEvent e, Board *B){

	if (turn){
		return executePlayerShort(ren, e, B);
	}
	else{
		return executePlayerCut(ren, e, B);
	}
}

/*****************************************************************************************************************************/
/********ADD YOUR OWN NEW METHODS HERE                                                                                 *******/
/*****************************************************************************************************************************/









