#include "MyGraphFunctions.h"
#include "Graph.h"
#include "PriorityQueue.h"
#include "InstructorGameLogic.h"

int shortestPath( Board *B, int s, int t ){  // move predecessors to an input so that ai works
	int distances[numNodes];
	int predecessors[numNodes];
	int visited[numNodes];
	int v;
	int dist;
	int pred;
	QueuePtr Q = initialize();
	
	for (int i = 0; i < numNodes; i++ ){
		distances[i] = noArc;
		visited[i] = 0;
		predecessors[i] = -1;
	}
	
	enqueue(Q, 0, 0, -1);
	
	while( !isEmpty(Q) ) {
		dequeue(Q, &v, &dist, &pred);
		if (!visited[v]) {
				visited[v] = 1;
				distances[v] = dist;
				predecessors[v] = pred;
				for (int w = 0; w < numNodes; w++) {
					if (!visited[w] && B->edges[v][w] != noArc){
						enqueue(Q, w, distances[v]+B->edges[v][w], v);
					}
				}
		}
	}
	
	return 0;
}