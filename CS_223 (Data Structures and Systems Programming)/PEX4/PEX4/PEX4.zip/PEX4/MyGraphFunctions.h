#include "Graph.h"

int shortestPath( Board *B, int s, int t );